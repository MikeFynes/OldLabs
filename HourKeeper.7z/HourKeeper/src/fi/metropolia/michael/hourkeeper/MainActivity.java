package fi.metropolia.michael.hourkeeper;


import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;

import java.text.SimpleDateFormat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class MainActivity extends Activity implements OnClickListener {

	private Button btnStart, btnStop, btnPrevious;
	private TextView lastText, hoursWorked, totalHours;
	private EditText userName; 
	private long firstSecs, lastSecs;
	private static final String fileName = "username.txt";
	private String stringyUsername;
	private int finalSecs;
	protected static final String PREF = "Username";
	DatabaseHelper d;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);

		SharedPreferences prefGet = getSharedPreferences(PREF, Activity.MODE_PRIVATE); 
        stringyUsername = prefGet.getString("Username", "");
        Log.d("MAIN ACTIVITY USERNAME GRAB", "USERNAME IS: "+stringyUsername );
		
		
		// CREATING DATABASE
		d = new DatabaseHelper(this);
		
		
	// USER NAME FIELD
		userName= (EditText) findViewById(R.id.userName);
		userName.setText(prefGet.getString("Username", ""));
	
	// START BUTTON
		btnStart = (Button) findViewById(R.id.btnStart);
		btnStart.setOnClickListener(this) ;
	
      
      // STOP BUTTON
      btnStop = (Button) findViewById(R.id.btnStop);
      btnStop.setOnClickListener(this); 
	
      
     // PREVIOUS HOURS BUTTON
      btnPrevious = (Button) findViewById(R.id.btnPrevious);
      btnPrevious.setOnClickListener(this); 
	
      // FIND TEXT VIEWS
      lastText = (TextView) findViewById (R.id.lastHours);
      hoursWorked = (TextView) findViewById(R.id.hoursWorked);
      totalHours = (TextView) findViewById(R.id.totalHours);
	}
	
	
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	

	

	@Override
	public void onClick(View v) {
		switch(v.getId()){
		
		case R.id.btnStart:
			// String firstDateTimeString = Date.toString(new Date());
			
			setFirstSecs((new Date().getTime()));
			SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy HH:mm", Locale.ENGLISH);
			sdf1.setTimeZone(TimeZone.getTimeZone("UTC"));
			String firstDate = sdf1.format(getFirstSecs());
			
			hoursWorked.setText(firstDate);
			setStringyUsername(userName.getText().toString());
			
		
			
			
			break;
			
		case R.id.btnStop:
			
			
			setLastSecs((new Date().getTime()));
			SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy HH:mm", Locale.ENGLISH);
			sdf2.setTimeZone(TimeZone.getTimeZone("UTC"));
			String lastDate = sdf2.format(getLastSecs());
			
			
			
			lastText.setText(lastDate);

			
			setFinalSecs((int) (getLastSecs() - getFirstSecs()));
			
			
			
			totalHours.setText(oldTime(getFinalSecs()));	
			
			
			
			if(getStringyUsername().matches("")){
				Toast.makeText(this, "You did not enter a username", Toast.LENGTH_SHORT).show();
			}
			else{
				d.insertData(stringyUsername, firstSecs, lastSecs, finalSecs);
			}
			
			Toast.makeText(this, "Hours saved!", Toast.LENGTH_SHORT).show();
			break;
			
		case R.id.btnPrevious:
			Intent myIntent = new Intent(this, SecActivity.class);
			startActivity(myIntent);
			
			break;
		}
	}
	// CONVERS TIME FROM MILLISECONDS TO HH:MM:SS FORMAT
	
		public String oldTime (int finalSecs){
			
			
	String time = "";
	    	
	   
	int hrs = (int) finalSecs/ (1000*60*60) % 24;
	if(hrs < 10)
		time += "0" + hrs +":";
	else
		time += hrs +":";

			int mins = (int) ((finalSecs / (1000*60)) % 60);
				if(mins < 10)
					time += "0" + mins+":";
				else
			time += mins+":";
	    	
	 		int secs = (int) (finalSecs / 1000) % 60;
	    	if(secs < 10)
	    		time += "0" + secs;
		   	else
		   		time += secs;
	    	
	     	
	    	
			return time;
			
			
			
			}
		
	/* // SAVE/OPEN FILE OUTPUT EXAMPLE NOT USED
		public void saveFile(String fName, String uname){
			
			
			try { 
			 FileOutputStream fOs = openFileOutput(fName, 0); 
			 OutputStreamWriter oSw = new OutputStreamWriter(fOs); 
			 BufferedWriter bW = new BufferedWriter(oSw); 
			 bW.write(uname); 
			 bW.flush(); 
			 bW.close(); 
			 oSw.close(); 
			 fOs.close(); 
			 
			 } 
			catch (Exception e) { 
			 Log.d("onClick", e.toString()); 
			 }
			}

		
		public String readFiles(String fname){
			
			String ch = stringyUsername;
			try { 
				 int content; 
				 BufferedReader bR = new BufferedReader(new InputStreamReader(openFileInput(fname))); 
				 String fContent=""; 
				 
				 while ((content = bR.read()) != -1) { 
				 fContent = fContent+(char)content;; 
				 }
				 ch = fContent;
				 bR.close(); 
				} 
				catch (Exception e) { 
				 Log.d("ERROR", e.toString()); 
				} 
				return ch;
				
		}
		*/





		public String getStringyUsername() {
			return this.stringyUsername;
		}





		public void setStringyUsername(String stringyUsername) {
			this.stringyUsername = stringyUsername;
			Log.d("USERNAME","USERNAME SAVED" +stringyUsername);
			SharedPreferences prefPut = getSharedPreferences(PREF, Activity.MODE_PRIVATE); 
            Editor prefEditor = prefPut.edit(); 
        	prefEditor.putString("Username", stringyUsername);
    		prefEditor.commit();
		}





		public long getFirstSecs() {
			return this.firstSecs;
		}





		public void setFirstSecs(long firstSecs) {
			this.firstSecs = firstSecs;
		}





		public long getLastSecs() {
			return this.lastSecs;
		}





		public void setLastSecs(long lastSecs) {
			this.lastSecs = lastSecs;
		}





		public int getFinalSecs() {
			return this.finalSecs;
		}





		public void setFinalSecs(int finalSecs) {
			this.finalSecs = finalSecs;
		}





		public static String getFilename() {
			return fileName;
		}
		
			


}
