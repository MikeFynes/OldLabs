/** Automatically generated file. DO NOT MODIFY */
package fi.metropolia.michael.hourkeeper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}